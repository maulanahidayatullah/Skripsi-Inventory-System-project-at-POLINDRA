
<?php $__env->startSection('content'); ?>
<title>Edit Data Guangan</title>
<div class="card-header py-3">
  <h6 class="m-0 font-weight-bold text-dark">Edit Data</h6>
</div>
<div class="card-body">
    <div class="x_content">
            <form action="/gedung/update" method="post">
                    <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                    <label for="">Nama Gedung</label>
                    <input type="text" name="gedung" class="form-control" value="<?php echo e($gedung->gedung); ?>" required placeholder="Masukan gedung">
                    <input type="hidden" name="id_gedung" class="form-control" value="<?php echo e($gedung->id_gedung); ?>" required placeholder="Masukan Jenis">
                  </div>
                  
                  
                  </div>
              </div>
                
          </div>
                  <button type="submit" class="btn btn-primary">Update</button>
            </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LaNa\Documents\_SKRIPSI\iso\laravel_sarpras\laravel_sarpras\resources\views/gedung/edit.blade.php ENDPATH**/ ?>