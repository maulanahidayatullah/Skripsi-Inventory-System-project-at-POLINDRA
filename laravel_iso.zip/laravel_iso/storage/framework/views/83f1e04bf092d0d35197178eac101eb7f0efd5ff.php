<table id="dataTable" class="table table-bordered" cellspacing="0">
          <thead>
            <tr>
                  <th>Barang</th>
                  <th>Jumlah</th>
                  <th>Tanggal Rusak</th>
                  <th>Status</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $rusak_luar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($m->nama_barang); ?></td>
                  <td><?php echo e($m->jumlah_rusak_luar); ?></td>
                  <td><?php echo e($m->tanggal_rusak_luar); ?></td>
                  <?php if($m->status=='sudah_diperbaiki'): ?>
                  <td>Sudah Di Perbaiki</td>
                  <?php else: ?>
                  <td>Rusak</td>
                  <?php endif; ?>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table><?php /**PATH C:\xampp\htdocs\laravel_sarpras\resources\views/laporan/table_rusak_luar.blade.php ENDPATH**/ ?>