
<?php $__env->startSection('content'); ?>
<title>Data Barang</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
</div>
 <div class="row"> 
  <div class="col-xl-6 col-md-12 mb-4">
    <div class="card border-left-dark shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-dark text-uppercase mb-1">Barang</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($barang); ?></div>
          </div>
          <div class="col-auto">
            <i class="fas fa fa-book fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
  
 </div>
 <div class="card shadow mb-4">
<div class="card-header py-3">
  <h6 class="m-0 font-weight-bold text-dark">Data Barang</h6>
</div>

<div class="card-body">
   
  <div class="table-responsive">
    <button class="btn btn-success" data-toggle="modal" data-target="#tambah">Tambah Data</button>
      <br>
      <br>
      <table id="example" class="table table-bordered js-basic-example dataTable" cellspacing="0">
          <thead>
            <tr>
              <th>No.</th>
              <th>Uraian Akun</th>
              <th>Kode Barang</th>
              <th>Nama Barang</th>
              <th>Tahun Perolehan</th>
              <th>NUP</th>
              <th>Merk/Type</th>
              <th>Kuantitas</th>
              <th>Nilai BMN</th>
              <th>Kondisi Barang</th>
              <th>Keberadaan Barang</th>
              <th>Pelabelan Kodefikasi</th>
              <th>Pegawai Pengguna Barang</th>
              <th>Nama Gedung</th>
              <th>Nama Ruangan</th>
              <th>Status PSP</th>
              <th>Nama Sub Satker</th>
              <th>Keterangan</th>
              <th>QR</th>
              <th>Opsi</th>
          </tr>
        </thead>
    </table>
          
  </div>
</div>

  <div id="tambah" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Masukan Data</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form action="<?php echo e(route('barang.store')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
              <label for="">Uraian Akun</label>
              <input type="text" name="uraian_akun" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">Kode Barang</label>
              <input type="text" name="kode_barang" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">Nama Barang</label>
              <input type="text" name="nama_barang" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">Tahun Perolehan</label>
              <input type="text" name="tahun_perolehan" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">NUP</label>
              <input type="text" name="nup" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">Merk/Type</label>
              <input type="text" name="merk_type" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">Kuantitas</label>
              <input type="number" name="kuantitas" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">Nilai BMN</label>
              <input type="number" name="nilai_bmn" class="form-control"  required>
          </div>
          <div class="form-group">
            <label for="">Kondisi Barang</label>
            <select class="form-control" id="">
                <option selected>Silahkan Pilih</option>
              <option value="B">B</option>
              <option value="RR">RR</option>
              <option value="RB">RB</option>
            </select>
          </div>
          <div class="form-group">
              <label for="">Keberadaan Barang</label>
              <select class="form-control" name="keberadaan_barang" aria-label="Default select example">
                <option selected>Silahkan Pilih</option>
                <option value="BD">BD</option>
                <option value="BTD">BTD</option>
                <option value="Berlebih">Berlebih</option>
              </select>
          </div>
          <div class="form-group">
              <label for="">Pelabelan Kodefikai</label>
              <select class="form-control" name="keberadaan_barang" aria-label="Default select example">
                <option selected>Silahkan Pilih</option>
                <option value="Sudah">Sudah</option>
                <option value="Belum">Belum</option>
                <option value="Berlebih">Berlebih</option>
              </select>
          </div>
          <div class="form-group">
              <label for="">Nama Pegawai Pengguna Barang</label>
              <input type="text" name="pegawai_id" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">Nama Gedung</label>
              <input type="text" name="gedung_id" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">Nama Ruangan</label>
              <input type="text" name="ruangan_id" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">Status PSP</label>
              <select class="form-control" name="keberadaan_barang" aria-label="Default select example">
                <option selected>Silahkan Pilih</option>
                <option value="Sudah">Sudah</option>
                <option value="Belum">Belum</option>
              </select>
          </div>
          <div class="form-group">
              <label for="">Status Sub Satker</label>
              <input type="text" name="status_sub_satker" class="form-control"  required>
          </div>
          <div class="form-group">
              <label for="">Keterangan</label>
              <input type="text" name="keterangan" class="form-control"  required>
          </div>
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
        </div>
      </div>
    </div>
  </div>

  <script>
 $(document).ready( function () {
    $('#example').DataTable({
           processing: true,
           serverSide: true,
           ajax: "/barang_json",
           columns: [
                    { data: 'DT_RowIndex', name: 'DT_RowIndex', oderable: false, searchable: false },
                    { data: 'uraian_akun', name: 'uraian_akun' },
                    { data: 'kode_barang', name: 'kode_barang' },
                    { data: 'nama_barang', name: 'nama_barang' },
                    { data: 'tahun_perolehan', name: 'tahun_perolehan' },
                    { data: 'nup', name: 'nup' },
                    { data: 'merk_type', name: 'merk_type' },
                    { data: 'kuantitas', name: 'kuantitas' },
                    { data: 'nilai_bmn', name: 'nilai_bmn' },
                    { data: 'kondisi_barang', name: 'kondisi_barang' },
                    { data: 'keberadaan_barang', name: 'keberadaan_barang' },
                    { data: 'pelabelan_kodefikasi', name: 'nampelabelan_kodefikasia_barang' },
                    { data: 'pegawai_id', name: 'pegawai_id' },
                    { data: 'gedung_id', name: 'gedung_id' },
                    { data: 'ruangan_id', name: 'ruangan_id' },
                    { data: 'status_psp', name: 'status_psp' },
                    { data: 'nama_sub_satker', name: 'nama_sub_satker' },
                    { data: 'qr', name: 'qr' },
                    { data: 'keterangan', name: 'keterangan' },
                    // { data: 'nama_kategori', name: 'nama_kategori' },
                    // { data: 'satuan', name: 'satuan' },
                    // { data: 'jumlah', name: 'jumlah' },
                    // { data: 'jumlah_rusak', name: 'jumlah_rusak' },
                    //  { data: 'total', name: 'total' },
                    {data: 'action', name: 'action', orderable: false},
                 ]
        });
     });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ata ias\backup\laravel_sarpras\resources\views/barang/view.blade.php ENDPATH**/ ?>