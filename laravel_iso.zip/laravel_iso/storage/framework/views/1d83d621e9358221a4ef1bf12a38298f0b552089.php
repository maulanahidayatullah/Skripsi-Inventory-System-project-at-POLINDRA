<table id="dataTable" class="table table-bordered" cellspacing="0">
          <thead>
            <tr>
                 
                  <th>Nama Peminjam</th>
                  <th>Barang</th>
                  <th>Jumlah</th>
                  <th>Tanggal Kembali</th>
                  <th>Status</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                 
                  <td><?php echo e($m->nama_peminjam); ?></td>
                  <td><?php echo e($m->nama_barang); ?></td>
                  <td><?php echo e($m->jumlah_pinjam); ?></td>
                  <td><?php echo e($m->tanggal_kembali); ?></td>
                  <td><?php echo e($m->status); ?></td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table><?php /**PATH C:\Users\LaNa\Documents\_SKRIPSI\_SourceCode\laravel_iso\resources\views/laporan/table_peminjaman.blade.php ENDPATH**/ ?>