
<?php $__env->startSection('content'); ?>
<title>Data Ruangan</title>

<div class="card-header py-3">
  <h6 class="m-0 font-weight-bold text-dark">Data Ruangan</h6>
</div>
<div class="card-body">
  <div class="table-responsive">
    <button class="btn btn-success" data-toggle="modal" data-target="#tambah">Tambah Data</button>
      <br>
      <br>
      <table id="dataTable" class="table table-bordered" cellspacing="0">
          <thead>
            <tr>
                  <th>No</th>
                  <th>Nama Gedung</th>
                  <th>Nama Ruangan</th>
                  <th>Opsi</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="data-row">
              <td class="align-middle iteration"><?php echo e(++$i); ?></td>
              <td class="align-middle id_barang"><?php echo e($u->gedung->gedung); ?></td>
              <td class="align-middle id_barang"><?php echo e($u->ruangan); ?></td>
              <td>  
                <div class="row">
                   <a href="/ruangan/edit/<?php echo e($u->id_ruangan); ?>" class="btn btn-primary btn-sm ml-2">Edit</a>
                   <a href="/ruangan/hapus/<?php echo e($u->id_ruangan); ?>" class="btn btn-danger btn-sm ml-2">Hapus</a>
                </div>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
  </div>
</div>

  <div id="tambah" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Masukan Data</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form action="/ruangan/store" method="post">
            <?php echo e(csrf_field()); ?>

          <div class="form-group">
              <label for="">Gedung</label>
              <select name="id_gedung"  class="myselect" id="" style="width:100%">
                <option value="" selected disabled>Pilih Gedung</option>
                <?php $__currentLoopData = $gedung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($a->id_gedung); ?>"><?php echo e($a->gedung); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
              </select>
          </div>
          <div class="form-group">
              <label for="">Ruangan</label>
              <input type="text" name="ruangan" class="form-control"  required>
          </div>
          
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LaNa\Documents\_SKRIPSI\iso\laravel_sarpras\laravel_sarpras\resources\views/ruangan/view.blade.php ENDPATH**/ ?>