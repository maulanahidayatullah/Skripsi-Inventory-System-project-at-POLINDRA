<label for="">Nama Ruangan</label>
<select class="myselect" id="ruangan" name="id_ruangan" style="width:100%">
    <option selected>Silahkan Pilih</option>
    <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item->id_ruangan); ?>"><?php echo e($item->ruangan); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH C:\Users\LaNa\Documents\_SKRIPSI\iso\laravel_sarpras\laravel_sarpras\resources\views/barang/card/ruangan_id.blade.php ENDPATH**/ ?>